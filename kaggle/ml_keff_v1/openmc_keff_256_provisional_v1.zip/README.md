# 256 k-effective senaryosu — geçici Kaggle verisi

Yalnız ilk keşif amaçlı ML karşılaştırması içindir. 256/256 k koşusu bilimsel inceleme bekliyor; fiziksel doğrulama ve eğitim kabulü verilmedi. 11 koşuda nükleer veri indeksi hash'i farklı; HDF5 eşdeğerliği doğrulanmadı.

ml_keff.csv sekiz fiziksel girdiyi, boyutsuz k_mean hedefini, k_mc_standard_error istatistiksel hatasını ve sabit split'i içerir. splits.json özgün kayıttır. bundle_hashes.json dosyaları doğrular. 3B alan verisi yoktur.

Notebook'u ayrıca Kaggle'a import edin. ZIP'i Dataset olarak Input'a bağlayın. Eğitim ve raporlar yalnız /kaggle/working altında oluşur.
