# halton_03: Halton 297–328

32 fixed cases. Use only the outer 01_kaggle_calistir.ipynb on Kaggle. The package notebooks exist for the current package hash format. completed is not physical or statistical acceptance.
